package com.example.supermarket;

import android.content.Context;
import android.media.Rating;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RatingAdapter extends RecyclerView.Adapter {
    private ArrayList<MarketRating> ratingData;
    private Context parentContext;
    boolean isDeleting;
    public Button buttonDeleteRating;
    private View.OnClickListener mOnItemClickListener;

    public class RatingViewHolder extends RecyclerView.ViewHolder {
        public TextView textRatingName;
        public TextView textRatingAddress;
        public TextView textRatingAverage;


        public RatingViewHolder(@NonNull View itemView) {
            super(itemView);
            textRatingName = itemView.findViewById(R.id.textRatingName);
            textRatingAddress = itemView.findViewById(R.id.textRatingAddress);
            textRatingAverage = itemView.findViewById(R.id.textRatingAverage);
            buttonDeleteRating = itemView.findViewById(R.id.buttonDeleteRating);
            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }

            public TextView getTextRatingName () {
                return textRatingName;
            }

            public TextView getTextRatingAddress () {
                return textRatingAddress;
            }

            public TextView getTextRatingAverage () {
                return textRatingAverage;
            }
            public Button getButtonDeleteMarketRating() {
                return buttonDeleteRating;
            }
        }

    public RatingAdapter(ArrayList<MarketRating> arrayList, Context context) {
        ratingData = arrayList;
        parentContext = context;
    }
    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new RatingViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
       RatingViewHolder rvh = (RatingViewHolder) holder;
        rvh.getTextRatingName().setText(ratingData.get(position).getRatingName());
        rvh.getTextRatingAddress().setText(ratingData.get(position).getRatingAddress());
        rvh.getTextRatingAverage().setText(ratingData.get(position).getRatingAverage());
        if (isDeleting)  {
            rvh.getButtonDeleteMarketRating().setVisibility(View.VISIBLE);
            rvh.getButtonDeleteMarketRating().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteRating(position);
                }
            });
        } else {
            rvh.getButtonDeleteMarketRating().setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return ratingData.size();
    }
    public void setDelete(boolean b) {
        isDeleting = b;
    }
    private void deleteRating(int position) {
        MarketRating rating = ratingData.get(position);
        RatingDataSource ds = new RatingDataSource(parentContext);
        try {
            ds.open();
            boolean didDelete = ds.deleteRating(rating.getRatingID());
            ds.close();
            if (didDelete) {
                ratingData.remove(position);
                notifyDataSetChanged();
            } else {
                Toast.makeText(parentContext, "Delete Failed!", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(parentContext, "Delete Failed!", Toast.LENGTH_LONG).show();
        }
    }
}

