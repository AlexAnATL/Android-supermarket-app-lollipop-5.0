
package com.example.supermarket;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Rating;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLException;

public class RateActivity extends AppCompatActivity {
    private float liquorStar = 0;
    private float produceStar = 0;
    private float meatStar = 0;
    private float cheeseStar = 0;
    private float checkoutStar = 0;
    private float ratingAverage = 0;

    private MarketRating currentRating = new MarketRating();
    private void updateCurrentTextRatingAverage(){
        TextView textCurrentRatingAverage = findViewById(R.id.textCurrentRatingAverage);
        textCurrentRatingAverage.setText("" + (liquorStar + produceStar
                + meatStar + cheeseStar + checkoutStar) / 5 );
    }
    private void initCancelRatingButton(){
        Button buttonCancelRating = findViewById(R.id.buttonCancelRating);
        buttonCancelRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
//update this method so users can update their ratings
    private void initSaveRatingButton(){
        Button buttonSaveRating = findViewById(R.id.buttonSaveRating);
        buttonSaveRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ratingAverage = (liquorStar + produceStar + meatStar + cheeseStar + checkoutStar)/ 5;
                currentRating.setLiquorRating(""+liquorStar);
                currentRating.setProduceRating(""+produceStar);
                currentRating.setMeatRating(""+meatStar);
                currentRating.setCheeseRating(""+cheeseStar);
                currentRating.setCheckoutRating(""+checkoutStar);
                currentRating.setRatingAverage(""+ratingAverage);
                boolean wasSuccessful;
                RatingDataSource ds = new RatingDataSource(RateActivity.this);
                try{
                    ds.open();
                        wasSuccessful = ds.insertRating(currentRating);
                        if(wasSuccessful){
                            int newId = ds.getLastRatingID()   ;
                            currentRating.setRatingID(newId);
                    }
                    ds.close();
                } catch (SQLException throwables) {
                }
                Intent intent = new Intent(RateActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    private void initRatingBars(){
        RatingBar ratingLiquor = findViewById(R.id.ratingLiquor);
        ratingLiquor.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                liquorStar = rating;
                updateCurrentTextRatingAverage();
            }
        });
        RatingBar ratingProduce = findViewById(R.id.ratingProduce);
        ratingProduce.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                produceStar = rating;
                updateCurrentTextRatingAverage();
            }
        });
        RatingBar ratingMeat = findViewById(R.id.ratingMeat);
        ratingMeat.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                meatStar = rating;
                updateCurrentTextRatingAverage();
            }
        });
        RatingBar ratingCheese = findViewById(R.id.ratingCheese);
        ratingCheese.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                cheeseStar = rating;
                updateCurrentTextRatingAverage();
            }
        });
        RatingBar ratingCheckout = findViewById(R.id.ratingCheckout);
        ratingCheckout.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                checkoutStar = rating;
                updateCurrentTextRatingAverage();
            }
        });
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initCurrentRating(int id){
        RatingDataSource ds = new RatingDataSource(RateActivity.this);
        try {
            ds.open();
            currentRating = ds.getSpecificRating(id);
            ds.close();
        }
        catch(Exception e) {
            Toast.makeText(this, "Load Rating Failed", Toast.LENGTH_LONG).show();
        }
        RatingBar ratingLiquor = findViewById(R.id.ratingLiquor);
        RatingBar ratingProduce = findViewById(R.id.ratingProduce);
        RatingBar ratingMeat = findViewById(R.id.ratingMeat);
        RatingBar ratingCheese = findViewById(R.id.ratingCheese);
        RatingBar ratingCheckout = findViewById(R.id.ratingCheckout);
        TextView  textCurrentRatingAverage  = findViewById(R.id.textCurrentRatingAverage);

        ratingLiquor.setRating(0 + Float.parseFloat(currentRating.getLiquorRating()));
        updateCurrentTextRatingAverage();
        ratingProduce.setRating(0 + Float.parseFloat(currentRating.getProduceRating()));
        updateCurrentTextRatingAverage();
        ratingMeat.setRating(0 + Float.parseFloat(currentRating.getMeatRating()));
        updateCurrentTextRatingAverage();
        ratingCheese.setRating(0 + Float.parseFloat(currentRating.getCheeseRating()));
        updateCurrentTextRatingAverage();
        ratingCheckout.setRating(0 + Float.parseFloat(currentRating.getCheckoutRating()));
        updateCurrentTextRatingAverage();
        textCurrentRatingAverage.setText("" + (Float.parseFloat(currentRating.getRatingAverage())));

    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initRating() {
        currentRating.setRatingName(MainActivity.getName());
        currentRating.setRatingAddress(MainActivity.getAddress());
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);
        Bundle extras = getIntent().getExtras();

        if(extras != null)  {
            initCurrentRating(extras.getInt("ratingID"));
        }
        else{
            initRating();
        }
        initRatingBars();
        initSaveRatingButton();
        initCancelRatingButton();
    }

}