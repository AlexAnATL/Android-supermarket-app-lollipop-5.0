package com.example.supermarket;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static String name;
    private static String address;

    public static String getName(){
        return name;
    }
    public void setName(String x) {
        name = x;
    }
    public static String getAddress(){
        return address;
    }
    public void setAddress(String x) {
        address = x;
    }
    public void initRateButton() {
        EditText editName = findViewById(R.id.editName);
        EditText editAddress = findViewById(R.id.editAddress);
        Button buttonRate = findViewById(R.id.buttonRate);
        buttonRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setName(editName.getText().toString());
                setAddress(editAddress.getText().toString());
                Intent intent = new Intent(MainActivity.this, RateActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRateButton();
        initDeleteSwitch();
    }
    public ArrayList<MarketRating> ratings;
    public RatingAdapter ratingAdapter;

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void onResume() {
        super.onResume();
        RatingDataSource ds = new RatingDataSource(this);

        try {
            ds.open();
            ratings = ds.getRatings();
            ds.close();
                RecyclerView contactList = findViewById(R.id.rvRatings);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
                contactList.setLayoutManager(layoutManager);
                ratingAdapter = new RatingAdapter(ratings, this);
                ratingAdapter.setOnItemClickListener(onItemClickListener);
                contactList.setAdapter(ratingAdapter);
            } catch(Exception e){
                Toast.makeText(this, "Error retrieving contacts", Toast.LENGTH_LONG).show();
            }
        }

    private void initDeleteSwitch() {
        Switch s = findViewById(R.id.switchDelete);
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {

                Boolean status = compoundButton.isChecked();
                ratingAdapter.setDelete(status);
                ratingAdapter.notifyDataSetChanged();
            }
        });
    }
    private View.OnClickListener onItemClickListener = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onClick(View view) {
            RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder)
                    view.getTag();
            int position = viewHolder.getAdapterPosition();
            int ratingId = ratings.get(position).getRatingID();
            Intent intent = new Intent(MainActivity.this, RateActivity.class);
            RatingDataSource ds = new RatingDataSource(MainActivity.this);
            intent.putExtra("ratingID", ratingId);
            startActivity(intent);
        }
    };

}