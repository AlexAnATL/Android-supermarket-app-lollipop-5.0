package com.example.supermarket;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.ByteArrayInputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

public class RatingDataSource {
    private SQLiteDatabase database;
    private RatingDBHelper dbHelper;

    public RatingDataSource(Context context) {
        dbHelper = new RatingDBHelper(context);
    }
    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }
    public void close(){
        dbHelper.close();
    }
    public boolean insertRating(MarketRating c) {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();
            initialValues.put("ratingname", c.getRatingName());
            initialValues.put("ratingaddress", c.getRatingAddress());
            initialValues.put("liquorrating", c.getLiquorRating());
            initialValues.put("producerating", c.getProduceRating());
            initialValues.put("meatrating", c.getMeatRating());
            initialValues.put("cheeserating", c.getCheeseRating());
            initialValues.put("checkoutrating", c.getCheckoutRating());
            initialValues.put("ratingaverage", c.getRatingAverage());

            didSucceed = database.insert("rating", null, initialValues) > 0;
        } catch (Exception e) {
            //do nothing -will return false if there is an exception
        }
        return didSucceed;
    }
    public int getLastRatingID() {
        int lastId;
        try {
            String query = "Select MAX(_id) from rating";
            Cursor cursor = database.rawQuery(query, null);

            cursor.moveToFirst();
            lastId = cursor.getInt(0);
            cursor.close();
        }
        catch (Exception e) {
            lastId = -1;
        }
        return lastId;
    }
    public boolean updateRating(MarketRating c) {
        boolean didSucceed = false;
        try {
            Long rowId = (long) c.getRatingID();
            ContentValues updateValues = new ContentValues();

            updateValues.put("ratingname", c.getRatingName());
            updateValues.put("ratingaddress", c.getRatingAddress());
            updateValues.put("liquorrating", c.getLiquorRating());
            updateValues.put("producerating", c.getProduceRating());
            updateValues.put("meatrating", c.getMeatRating());
            updateValues.put("cheeserating", c.getCheeseRating());
            updateValues.put("checkoutrating", c.getCheckoutRating());
            updateValues.put("ratingaverage", c.getRatingAverage());

            didSucceed = database.update("rating", updateValues, "_id=" + rowId, null) > 0;
        }
        catch(Exception e){

        }
        return didSucceed;
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public ArrayList<MarketRating> getRatings(){
        ArrayList<MarketRating> ratings = new ArrayList<MarketRating>();
        try {
            String query = "SELECT * FROM rating";
            Cursor cursor = database.rawQuery(query, null);

            MarketRating newRating;
            cursor.moveToFirst();
            while(!cursor.isAfterLast()) {
                newRating = new MarketRating();
                newRating.setRatingID(cursor.getInt(0));
                newRating.setRatingName(cursor.getString(1));
                newRating.setRatingAddress(cursor.getString(2));
                newRating.setLiquorRating(cursor.getString(3));
                newRating.setProduceRating(cursor.getString(4));
                newRating.setMeatRating(cursor.getString(5));
                newRating.setCheeseRating(cursor.getString(6));
                newRating.setCheckoutRating(cursor.getString(7));
                newRating.setRatingAverage(cursor.getString(8));
                ratings.add(newRating);
                cursor.moveToNext();
            }
            cursor.close();
        }
        catch(Exception e){
            ratings = new ArrayList<MarketRating>();
        }
        return ratings;
    }
    public boolean deleteRating(int contactId) {
        boolean didDelete = false;
        try {
            didDelete = database.delete("rating", "_id = " + contactId, null) > 0;
        }
        catch(Exception e) {
            //Do nothing -return value already set to false
        }
        return didDelete;
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public MarketRating getSpecificRating(int ratingId) {
        MarketRating rating = new MarketRating();
        String query = "SELECT * FROM rating WHERE _id =" + ratingId;
        Cursor cursor = database.rawQuery(query, null);
        if(cursor.moveToFirst()) {
            rating.setRatingID(cursor.getInt(0));
            rating.setLiquorRating(cursor.getString(3));
            rating.setProduceRating(cursor.getString(4));
            rating.setMeatRating(cursor.getString(5));
            rating.setCheeseRating(cursor.getString(6));
            rating.setCheckoutRating(cursor.getString(7));
            rating.setRatingAverage(cursor.getString(8));

            cursor.close();
        }
        return rating;
    }
}
