package com.example.supermarket;

public class MarketRating {
    private int ratingID;
    private String ratingName;
    private String ratingAddress;
    private String liquorRating;
    private String produceRating;
    private String meatRating;
    private String cheeseRating;
    private String checkoutRating;
    private String ratingAverage;

    public MarketRating() {
        ratingID = -1;
    }
    public int getRatingID() {
        return ratingID;
    }
    public void setRatingID(int i) {
        ratingID = i;
    }
    public String getRatingName(){
        return ratingName;
    }
    public void setRatingName(String ratingName){
        this.ratingName = ratingName;
    }
    public String getRatingAddress() {
        return ratingAddress;
    }
    public void setRatingAddress(String ratingAddress){
        this.ratingAddress = ratingAddress;
    }
    public String getLiquorRating(){
        return liquorRating;
    }
    public void setLiquorRating(String liquorRating){
        this.liquorRating = liquorRating;
    }
    public String getProduceRating(){
        return produceRating;
    }
    public void setProduceRating(String produceRating){
        this.produceRating = produceRating;
    }
    public String getMeatRating(){
        return meatRating;
    }
    public void setMeatRating(String meatRating){
        this.meatRating = meatRating;
    }
    public String getCheeseRating(){
        return cheeseRating;
    }
    public void setCheeseRating(String cheeseRating){
        this.cheeseRating = cheeseRating;
    }
    public String getCheckoutRating(){
        return checkoutRating;
    }
    public void setCheckoutRating(String checkoutRating){
        this.checkoutRating = checkoutRating;
    }




    public String getRatingAverage() {
        return ratingAverage;
    }
    public void setRatingAverage(String ratingAverage){
        this.ratingAverage = ratingAverage;
    }
}
